# tests/test_sample.py
def test_example():
    assert 1 + 1 == 2
